package com.training;

public interface StudentDAO {

	
	/** 
	    * This is the method to be used to list down
	    * a record from the Student table corresponding
	    * to a passed student id.
	    */
	   public Student getStudent(Integer id);
}
