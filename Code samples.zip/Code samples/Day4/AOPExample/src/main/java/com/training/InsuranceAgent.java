package com.training;

public class InsuranceAgent {
	
	public void insureCar(){
		System.out.println("Car is insured");
	}

}
