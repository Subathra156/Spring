package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.List;

public class CollectionDemo {
	
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
 
		// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
 
				
		//example for bean scope:singleton and prototype
		CricketClub club = (CricketClub)context.getBean("club");
	
		List <String>  members=club.getMembers();
		
		for(String member:members){
			
			System.out.println("Member name: "+ member);
			
		}
	

}

}