package com.training;
import java.util.List;

public class CricketClub {
	
	private List<String> members;
	
	public List<String> getMembers() {
		return members;
	}

	public void setMembers(List<String> members) {
		this.members = members;
	}

	
	
	

	
	
	

}
