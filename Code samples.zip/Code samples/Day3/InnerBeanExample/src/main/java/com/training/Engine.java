package com.training;

public class Engine {
	
	public String getEngineNumber(){
		
		return "3639";
		
	}

}
