package com.training;

public class Car {
	
	private Engine myEngine;

	public Engine getMyEngine() {
		return myEngine;
	}

	public void setMyEngine(Engine myEngine) {
		this.myEngine = myEngine;
	}
	
	

}
