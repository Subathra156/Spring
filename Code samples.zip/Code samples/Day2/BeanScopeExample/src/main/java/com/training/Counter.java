package com.training;

public class Counter {
	
	int count=1;
	
	public void incrementCounter(){
		
		++count;
		System.out.println("Count value "+ count );
	}

}
