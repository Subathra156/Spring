package com.training;

public class Maruti implements CarCompany{
	
public void deliverCar(){
		
		System.out.println("Car delivered by Maruti");
	}

}
